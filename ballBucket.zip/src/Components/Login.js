import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Style.css";
import axios from "axios";

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();

    axios
      .post("http://localhost:5000/api/login", {
        email,
        password,
      })
      .then((response) => {
        const { token } = response.data;
        localStorage.setItem("token", token);
        navigate("/");
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <>
      <div className="grid grid-cols-3 relative text-black p-10">
        <div className="absolute left-[60%] top-1/2 h-20 w-20 rounded-full bg-[#1930e1] circle2"></div>
        <div className="absolute right-[60%] top-[15%] h-20 w-20 rounded-full bg-[#be16f1] circle2"></div>
        <div className="absolute right-[50%] bottom-[15%] h-20 w-20 rounded-full bg-[#f11683] circle2"></div>

        <div className="col-span-1"></div>
        <form
          onSubmit={handleLogin}
          className="form1 flex flex-col justify-start items-center col-span-1  neumorphism border p-10 font-medium"
        >
          <div className="m-3 text-center">
            <label>Email:</label>
            <br />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="bg-transparent border rounded-md px-3"
            />
          </div>
          <div className="m-3 text-center">
            <label>Password:</label>
            <br />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="bg-transparent border rounded-md px-3"
            />
          </div>
          <button className="my-5">
            <span className="shadow"></span>
            <span className="edge"></span>
            <span className="front text">Login</span>
          </button>
          <p>
            Don't have an account?{" "}
            <Link to="/signup" className="hover:text-[#a30036]">
              Signup
            </Link>
          </p>
        </form>

        <div className="col-span-1"></div>
      </div>
    </>
  );
}

export default Login;
