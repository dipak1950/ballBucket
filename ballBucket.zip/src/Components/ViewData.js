import React, { useEffect, useState } from "react";
import axios from "axios";

function ViewData() {
  const [buckets, setBuckets] = useState([]);
  // console.log(buckets, "cccccccccccccccccccccccccc");

  const fetchBucketData = () => {
    const token = localStorage.getItem("token");

    axios
      .get("http://localhost:5000/api/view/bucket", {
        headers: {
          Authorization: token,
        },
      })
      .then((response) => {
        setBuckets(response.data);
        // console.log(response.data, "fffffff");
      })
      .catch((error) => {
        console.log(error);
      });
  };

  useEffect(() => {
    fetchBucketData();
  }, []);

  return (
    <>
      <div className="text-white">
        <h2>Bucket List</h2>
        {buckets.bucket && buckets.bucket.length > 0 ? (
          <table className="text-white">
            <thead>
              <tr>
                <th>Bucket Name</th>
                <th>Bucket Size</th>
              </tr>
            </thead>
            <tbody>
              {buckets.bucket.map((bucket) => (
                <tr key={bucket._id}>
                  <td>{bucket.name}</td>
                  <td>{bucket.size}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>No buckets available.</p>
        )}
      </div>
    </>
  );
}

export default ViewData;
