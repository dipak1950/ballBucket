import React from "react";
import BucketForm from "./Components/BucketForm";
import Suggetion from "./Components/Suggetion";
import { Route, Routes } from "react-router-dom";
import ViewData from "./Components/ViewData";

const App = () => {
  return (
    <>
      <div className=" relative flex flex-col justify-center items-center p-20">
        <Routes>
          <Route path="/BucketForm" element={<BucketForm />} />
          <Route path="/Suggetion" element={<Suggetion />} />
          <Route path="/view" element={<ViewData />} />
        </Routes>
      </div>
    </>
  );
};

export default App;
